# 🏷️ 追蹤清單分組 Tag 功能整合

## 🚀 一鍵部署

```bash
# 解壓後在專案根目錄執行
unzip tag_integration.zip
cp tag_integration/static/js/tags.js static/js/
cp tag_integration/static/js/watchlist.js static/js/
patch -p1 < tag_integration/dashboard.patch
git add . && git commit -m "feat: 追蹤清單標籤整合" && git push
```

## ✅ 功能說明

### 標籤篩選
- 追蹤清單頁面頂部會顯示標籤篩選器
- 點擊標籤可以篩選顯示特定標籤的股票

### 標籤顯示
- 每個追蹤項目卡片會顯示其標籤 badges

### 設定標籤
- 每個卡片右下角新增「標籤」按鈕
- 點擊後可以為該股票設定/修改標籤

### 標籤管理
- 在「設定」頁面可以管理標籤
- 新增/編輯/刪除自訂標籤
- 選擇顏色和圖示

## 📦 檔案清單

```
tag_integration/
├── static/js/
│   ├── watchlist.js   # 整合標籤功能版本
│   └── tags.js        # 標籤管理模組（從現有複製）
└── README.md          # 本說明文件
```

## 🔧 API 端點（已存在）

| 方法 | 端點 | 說明 |
|------|------|------|
| GET | `/api/tags` | 取得用戶標籤 |
| POST | `/api/tags` | 新增標籤 |
| PUT | `/api/tags/{id}` | 更新標籤 |
| DELETE | `/api/tags/{id}` | 刪除標籤 |
| GET | `/api/tags/watchlist/{id}` | 取得追蹤項目標籤 |
| PUT | `/api/tags/watchlist/{id}` | 設定追蹤項目標籤 |
| POST | `/api/tags/init-defaults` | 初始化預設標籤 |
